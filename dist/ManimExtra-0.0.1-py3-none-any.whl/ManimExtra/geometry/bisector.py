from manim import *

def x():
    circle = Circle()
    return circle