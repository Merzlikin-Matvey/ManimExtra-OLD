from __future__ import annotations


class EndSceneEarlyException(Exception):
    pass


class RerunSceneException(Exception):
    pass


class MultiAnimationOverrideException(Exception):
    pass
